import { GrifaTextoDirective } from './grifa-texto.directive';

describe('GrifaTextoDirective', () => {
  it('should create an instance', () => {
    const directive = new GrifaTextoDirective();
    expect(directive).toBeTruthy();
  });
});
